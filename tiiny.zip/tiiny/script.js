//securiry start
document.addEventListener('mousedown', (event) => {
   if (event.button == 2){
     alert('warn! Dont use right click')
   }
});
//security end

//go to https://mapspritesheet.netlify.app/

function GoTo(){
	const a = document.createElement('a');
	a.setAttribute('href', 'https://mapspritesheet.netlify.app/');
	a.click();
}
const AddImageBtn = document.querySelector('.AddImageBtn');

const cancelDynamic = document.querySelector('.cancel-Dynamic');

const Behavers = [0, 1, 2, 3, 4, 5];

var ImagesData = {}

//const ImagesData = {1: {'url':"/storage/emulated/0/Codes/assets/wall1.jpg", "width": 1,"height": 1, "behaver": 1, 'selected': false}}

let data = JSON.parse(localStorage.getItem('completed'));

const CompletedData = data == null ? {} : data;
//console.log(CompletedData);
//localStorage.clear();
//completed={nameSheet:{measured: measured[{}], structure:'url'},nameSheet2:{measured: measured, structure:url}}

function setCompleted() {
  localStorage.clear();
  data = JSON.stringify(CompletedData);
  localStorage.setItem('completed', data);
};

function copy_completed(teaxArea) {
  textArea.select();
  document.execCommand('copy');
}
function download_completed(key) {
  url = CompletedData[key]['structure'];
  a = document.createElement('a');
  a.setAttribute('href', url);
  a.setAttribute('download', key + '.png');
  a.click();
}
function delete_completed(key) {
  delete CompletedData[key];
  loadCompleted();
  setCompleted();
}

function loadCompleted() {
  place = document.querySelector('#completePlace');
  place.innerText = '';
  Object.keys(CompletedData).forEach((name) => {
    card = document.createElement('div');
    card.classList.add('completedCard');
    card.classList.add('makeCenter');
    jaga = document.createElement('div');
    jaga.classList.add('jaga');
    structure = document.createElement('div');
    structure.classList.add('structure');
    url = `url(${CompletedData[name]['structure']})`;
    structure.style.backgroundImage = url;
    structure.style.backgroundRepeat = 'no-repeat';
    structure.style.backgroundSize = '100% 100%';
    structure.style.backgroundPosition = 'center center';
    textArea = document.createElement('textarea');
    text = JSON.stringify(CompletedData[name]['measured']);
    //console.log(text);
    textArea.value = text;
    textArea.classList.add('measured');
    options = document.createElement('div');
    options.classList.add('options');
    head = document.createElement('a');
    head.innerText = name;
    head.style.fontSize = '10px';
    head.style.color = 'white';
    copyI = document.createElement('i');
    copyI.classList.add('fa', 'fa-copy');
    copyI.onclick = () => { copy_completed(textArea) };
    downloadI = document.createElement('i');
    downloadI.classList.add('fa', 'fa-download');
    downloadI.onclick = () => { download_completed(name) };
    deleteI = document.createElement('i');
    deleteI.classList.add('fa', 'fa-trash');
    deleteI.onclick = () => { delete_completed(name) };

    options.appendChild(head);
    options.appendChild(copyI);
    options.appendChild(downloadI);
    options.appendChild(deleteI);
    jaga.appendChild(structure);
    jaga.appendChild(textArea);
    jaga.appendChild(options);
    card.appendChild(jaga);
    place.appendChild(card);
  });
}

function DynamicPage(path) {

  const Dynamic = document.querySelector('.Dynamic');

  const Main = document.querySelector('.Main');

  Main.style.display = 'none';

  Dynamic.style.display = 'block';

  const DPages = document.querySelectorAll('.DPage');

  DPages.forEach((dpage) => {

    if (dpage.classList.contains(path)) {

      dpage.style.display = 'block';

    }

    else {

      dpage.style.display = 'none';

    }

  });

}

function MainPage() {

  const Dynamic = document.querySelector('.Dynamic');

  const Main = document.querySelector('.Main');

  Main.style.display = 'block';

  Dynamic.style.display = 'none';

}

cancelDynamic.addEventListener('click', MainPage);

// Add image

AddImageBtn.addEventListener('click', () => {

  document.querySelector('#imageBoxAdd').style.backgroundImage = 'none';

  document.querySelector('#widthAdd').value = '1';

  document.querySelector('#heightAdd').value = '1';

  document.querySelector('#behaverAdd').value = '1';

  document.querySelector('#urlPathAdd').value = '';

  DynamicPage('AddImage');

});

document.querySelector('.upWidthAdd').addEventListener('click', () => {

  document.querySelector('#widthAdd').value = `${parseInt(document.querySelector('#widthAdd').value) + 1}`;

});

document.querySelector('.downWidthAdd').addEventListener('click', () => {

  if (document.querySelector('#widthAdd').value == '1') { return; }

  document.querySelector('#widthAdd').value = `${parseInt(document.querySelector('#widthAdd').value) - 1}`;

});

document.querySelector('.upHeightAdd').addEventListener('click', () => {

  document.querySelector('#heightAdd').value = `${parseInt(document.querySelector('#heightAdd').value) + 1}`;

});

document.querySelector('.downHeightAdd').addEventListener('click', () => {

  if (document.querySelector('#heightAdd').value == '1') { return; }

  document.querySelector('#heightAdd').value = `${parseInt(document.querySelector('#heightAdd').value) - 1}`;

});

document.querySelector('.upBehaverAdd').addEventListener('click', () => {

  document.querySelector('#behaverAdd').value = `${parseInt(document.querySelector('#behaverAdd').value) + 1}`;

});

document.querySelector('.downBehaverAdd').addEventListener('click', () => {

  document.querySelector('#behaverAdd').value = `${parseInt(document.querySelector('#behaverAdd').value) - 1}`;

});

document.querySelector('#imgOk').addEventListener('click', () => {
  w = document.querySelector('#widthAdd');
  h = document.querySelector('#heightAdd');
  b = document.querySelector('#behaverAdd');
  path = document.querySelector('#urlPathAdd');
  wv = parseInt(w.value);
  hv = parseInt(h.value);
  bv = parseInt(b.value);
  if (wv <= 0) { showErrorAdd(w); return; } else { raseErrorAdd(w) }
  if (hv <= 0) { showErrorAdd(h); return; } else { raseErrorAdd(h) }
  if (!(bv in Behavers)) { showErrorAdd(b); return; } else { raseErrorAdd(b) }
  if (path.value == '') { return }

  var num = 1;
  if (ImagesData.lenght != 0) {
    var lastKey = Math.max(Object.keys(ImagesData));
    num = num + lastKey;
  }

  ImagesData[num] = { 'url': path.value, 'width': wv, 'height': hv, 'behaver': bv, 'selected': false }
  imagesLoader();
  MainPage();
});

// browse
document.querySelector('#urlPathAdd').addEventListener('input', (event) => { })

document.querySelector('#urlGetAdd').addEventListener('change', (event) => {

  const file = event.target.files[0];
  const path = URL.createObjectURL(file);
  document.querySelector('#urlPathAdd').value = path;
  const img = document.querySelector('#imageBoxAdd');
  img.style.backgroundImage = `url(${path})`;
  img.style.backgroundRepeat = 'no-repeat';
  img.style.backgroundSize = '100% 100%';
  img.style.backgroundPosition = 'center center';
});



document.querySelector('#urlPathEdit').addEventListener('input', (event) => { })

document.querySelector('#urlGetEdit').addEventListener('change', (event) => {

  const file = event.target.files[0];

  const path = URL.createObjectURL(file);

  document.querySelector('#urlPathEdit').value = path;

  const img = document.querySelector('#imageBoxEdit');

  img.style.backgroundImage = `url(${path})`;

  img.style.backgroundRepeat = 'no-repeat';

  img.style.backgroundSize = '100% 100%';

  img.style.backgroundPosition = 'center center';

});

function showErrorAdd(id) {

  id.style.color = 'red';

}

function raseErrorAdd(id) {

  id.style.color = 'black';

}

function imagesLoader() {
  const parent = document.querySelector('#images');
  parent.innerHTML = '';
  let new_ImagesData = {}
  Object.keys(ImagesData).forEach((key, index) => {
    let num = index + 1;
    new_ImagesData[num] = ImagesData[key];
  });
  ImagesData = new_ImagesData;
  Object.keys(ImagesData).forEach((key, index) => {
    const card = document.createElement('div');
    card.classList.add('imgCard');
    card.classList.add('hover');
    card.onclick = () => Select(event);
    const box = document.createElement('div');
    box.classList.add('imgBox');
    box.style.backgroundImage = `url(${ImagesData[key]['url']})`;
    box.style.backgroundRepeat = 'no-repeat';
    box.style.backgroundSize = '100% 100%';
    box.style.backgroundPosition = 'center center';
    card.appendChild(box);
    parent.appendChild(card);
  });
}

function Select(event) {
  const keys = Object.keys(ImagesData);
  const boxes = document.querySelectorAll('.imgBox');
  boxes.forEach((box, index) => {
    box.classList.remove('select');
  });
  event.target.classList.add('select');
  keys.forEach((key, index) => {
    if (boxes[index].classList.contains('select')) {
      ImagesData[key]['selected'] = true;
    }
    else {
      ImagesData[key]['selected'] = false;
    }
  });
}

// Edit

document.querySelector('.imageEditBtn').addEventListener('click', () => {

  const boxes = document.querySelectorAll('.imgBox');

  boxes.forEach((box) => {

    if (box.classList.contains('select')) {

      const box = document.querySelector('#imageBoxEdit');

      Object.keys(ImagesData).forEach((key, index) => {

        if (ImagesData[key]['selected']) {

          box.style.backgroundImage = `url(${ImagesData[key]['url']})`;

          box.style.backgroundRepeat = 'no-repeat';

          box.style.backgroundSize = '100% 100%';

          box.style.backgroundPosition = 'center center';



          document.querySelector('#urlPathEdit').value = ImagesData[key]['url'];

          document.querySelector('#widthEdit').value = ImagesData[key]['width'];

          document.querySelector('#heightEdit').value = ImagesData[key]['height'];

          document.querySelector('#behaverEdit').value = ImagesData[key]['behaver'];

        }

      });

      DynamicPage('EditImage');

      return;

    }

  });



});

document.querySelector('.upWidthEdit').addEventListener('click', () => {

  document.querySelector('#widthEdit').value = `${parseInt(document.querySelector('#widthEdit').value) + 1}`;

});

document.querySelector('.downWidthEdit').addEventListener('click', () => {

  if (document.querySelector('#widthEdit').value == '1') { return; }

  document.querySelector('#widthEdit').value = `${parseInt(document.querySelector('#widthEdit').value) - 1}`;

});

document.querySelector('.upHeightEdit').addEventListener('click', () => {

  document.querySelector('#heightEdit').value = `${parseInt(document.querySelector('#heightEdit').value) + 1}`;

});

document.querySelector('.downHeightEdit').addEventListener('click', () => {

  if (document.querySelector('#heightEdit').value == '1') { return; }

  document.querySelector('#heightEdit').value = `${parseInt(document.querySelector('#heightEdit').value) - 1}`;

});

document.querySelector('.upBehaverEdit').addEventListener('click', () => {

  document.querySelector('#behaverEdit').value = `${parseInt(document.querySelector('#behaverEdit').value) + 1}`;

});

document.querySelector('.downBehaverEdit').addEventListener('click', () => {

  document.querySelector('#behaverEdit').value = `${parseInt(document.querySelector('#behaverEdit').value) - 1}`;

});

document.querySelector('#imgRemove').addEventListener('click', () => {

  Object.keys(ImagesData).forEach((key) => {

    if (ImagesData[key]['selected']) {

      delete ImagesData[key];

    }

  });

  imagesLoader();

  MainPage();

});

document.querySelector('#editOk').addEventListener('click', () => {

  w = document.querySelector('#widthEdit');

  h = document.querySelector('#heightEdit');

  b = document.querySelector('#behaverEdit');

  path = document.querySelector('#urlPathEdit');

  wv = parseInt(w.value);

  hv = parseInt(h.value);

  bv = parseInt(b.value);

  if (wv <= 0) { showErrorAdd(w); return; } else { raseErrorAdd(w) }

  if (hv <= 0) { showErrorAdd(h); return; } else { raseErrorAdd(h) }

  if (!(bv in Behavers)) { showErrorAdd(b); return; } else { raseErrorAdd(b) }

  if (path.value == '') { return }

  const keys = Object.keys(ImagesData);

  keys.forEach((key, index) => {

    if (ImagesData[key]['selected']) {

      ImagesData[key] = { 'url': path.value, 'width': wv, 'height': hv, 'behaver': bv, 'selected': false }

      return;

    }

  });

  imagesLoader();

  MainPage();

});

var SELECTED_BG = 'transparent';

const selectedBGO = document.querySelector('#selectedBGO');
selectedBGO.addEventListener('click', () => {
  const inners = document.querySelector('#inners');
  inners.style.display = 'block';
});
const bgbrowse =document.querySelector('#bgbrowse');
bgbrowse.addEventListener('change', (e) => {
  const selectedBG = document.querySelector('#selectedBG');
  let file = bgbrowse.files[0];
  let reader = new FileReader();
  reader.onload = () => {
    selectedBG.className = 'bgImage';
    selectedBG.innerText = '';
    selectedBG.style.backgroundImage = `url(${reader.result})`;
    SELECTED_BG = reader.result;
  }
  reader.readAsDataURL(file);
})

const colorsS = document.querySelectorAll('.rgb');
const rgbRender = document.querySelector('.renderRGB');
for (let i = 0; i<colorsS.length; i++){
  colorsS[i].addEventListener('change', () => {
    const r = document.querySelector('#r');
    const g = document.querySelector('#g');
    const b = document.querySelector('#b');

    let rv = parseInt(r.value);
    let gv = parseInt(g.value);
    let bv = parseInt(b.value);
    rgbRender.style.backgroundColor = `rgba(${rv}, ${gv}, ${bv})`;
  })
}

function bgOK(event){
  const selectedBG = document.querySelector('#selectedBG');
  if (event.target.id == 'trans'){
    selectedBG.className = '';
    selectedBG.innerText = event.target.innerText;
    selectedBG.style.backgroundColor = 'transparent';
    SELECTED_BG = 'transparent';
    selectedBG.style.backgroundImage = 'none';
  };
  if (event.target.id == 'okBG'){
    selectedBG.className = '';
    const r = document.querySelector('#r');
    const g = document.querySelector('#g');
    const b = document.querySelector('#b');
    let rv = parseInt(r.value);
    let gv = parseInt(g.value);
    let bv = parseInt(b.value);
    selectedBG.style.backgroundColor = 'transparent';
    selectedBG.style.backgroundImage = 'none';
    SELECTED_BG = [rv, gv, bv];
    selectedBG.innerHTML = `<div style='background-color:rgba(${rv}, ${gv}, ${bv});width:25px;height:25px; display:inline-block;'></div>`;
  };


  const inners = document.querySelector('#inners');
  inners.style.display = 'none';
}

const dropZone = document.querySelector('#dropZone');
dropZone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropZone.style.backgroundColor = 'lightgreen';
});
dropZone.addEventListener('dragleave', (e) => {
  e.preventDefault();
  dropZone.style.backgroundColor = 'lightgreen';
});
dropZone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropZone.style.backgroundColor = '';
  const files = e.dataTransfer.files;
  for (const file of files){
    const reader = new FileReader();
    reader.onload = () => {
      let url = reader.result;
      var num = 1;
      if (ImagesData.lenght != 0) {
        var lastKey = Math.max(Object.keys(ImagesData));
        num = num + lastKey;
      }

      ImagesData[num] = { 'url': url, 'width': 1, 'height': 1, 'behaver': 1, 'selected': false }
      imagesLoader();
    }
    reader.readAsDataURL(file);
  }
});

// Mapping Area

const canvas = document.querySelector('#sheet');
const ctx = canvas.getContext('2d');

var ScaleX = 50;
var ScaleY = 50;
var positions = {}
var columns = [];
var colsS = 2;
var rows = [];
var rowsS = 2;
var mouseX = 0;
var mouseY = 0;
let complete = false;

canvas.addEventListener('mousemove', (e) => {
  const rect = canvas.getBoundingClientRect();
  mouseX = e.clientX - rect.left;
  mouseY = e.clientY - rect.top;
});
canvas.addEventListener('click', () => {
  if (!complete) {
    let mx = mouseX / ScaleX | 0;
    let my = mouseY / ScaleY | 0;
    if (positions[[mx, my]]) {
      delete positions[[mx, my]];
      return;
    }
    let x = mx * ScaleX;
    let y = my * ScaleY;
    let img = new Image();
    let w = null;
    let h = null;
    let b = null;
    Object.keys(ImagesData).forEach((key, index) => {
      if (ImagesData[key]['selected']) {
        img.src = ImagesData[key]['url'];
        w = ImagesData[key]['width'];
        h = ImagesData[key]['height'];
        b = ImagesData[key]['behaver'];
      }
    });
    positions[[mx, my]] = {
      'x': x, 'y': y, 'img': img,
      'w': w, 'h': h, 'b': b
    }
  }
});

const column_manage = () => {
  //canvas width = cols
  const colInput = document.querySelector('#column');
  const colValue = parseInt(colInput.value);
  colsS = colValue;
  columns = []; // clear array
  for (let column = 0; column < colValue; column++) {
    if (column === 0) { continue; }
    x = column * ScaleX;
    columns.push(x);
  }
  canvas.width = colsS * ScaleX;
}
const row_manage = () => {
  //canvas height = rows
  const rowInput = document.querySelector('#row');
  const rowValue = parseInt(rowInput.value);
  rowsS = rowValue;
  rows = []; // clear array
  for (let row = 0; row < rowValue; row++) {
    if (row === 0) { continue; }
    y = row * ScaleY;
    rows.push(y);
  }
  canvas.height = rowsS * ScaleY;
}

function upColumn() {
  colsS++;
  col = document.querySelector('#column');
  col.value = `${parseInt(col.value) + 1}`;
  column_manage();
}
function downColumn() {
  colsS--;
  col = document.querySelector('#column');
  if (col.value == '2') { return; }
  col.value = `${parseInt(col.value) - 1}`;
  column_manage();
}

function upRow() {
  rowsS++;
  row = document.querySelector('#row');
  row.value = `${parseInt(row.value) + 1}`;
  row_manage();
}
function downRow() {
  rowsS--;
  row = document.querySelector('#row');
  if (row.value == '2') { return; }
  row.value = `${parseInt(row.value) - 1}`;
  row_manage();
}

document.querySelector('#column').addEventListener('input', column_manage);
document.querySelector('#row').addEventListener('input', row_manage);

const scaleX_manage = () => {
  sx = document.querySelector('#scaleX');
  ScaleX = parseInt(sx.value);
  Object.keys(positions).forEach((pos) => {
    positions[pos]['x'] = pos[0] * ScaleX;
  });
  column_manage();
}
const scaleY_manage = () => {
  sy = document.querySelector('#scaleY');
  ScaleY = parseInt(sy.value);
  Object.keys(positions).forEach((pos) => {
    positions[pos]['y'] = pos[2] * ScaleY;
  });
  row_manage();
}

function upScaleX() {
  ScaleX++;
  sx = document.querySelector('#scaleX');
  sx.value = `${ScaleX}`;
  scaleX_manage();
}
function downScaleX() {
  ScaleX--;
  sx = document.querySelector('#scaleX');
  sx.value = `${ScaleX}`;
  scaleX_manage();
}

function upScaleY() {
  ScaleY++;
  sy = document.querySelector('#scaleY');
  sy.value = `${ScaleY}`;
  scaleY_manage();
}
function downScaleY() {
  ScaleY--;
  sy = document.querySelector('#scaleY');
  sy.value = `${ScaleY}`;
  scaleY_manage();
}

document.querySelector('#scaleX').addEventListener('input', scaleX_manage);
document.querySelector('#scaleY').addEventListener('input', scaleY_manage);


const showplace = (iw, ih) => {
  ctx.strokeStyle = 'green';
  ox = mouseX / ScaleX | 0;
  oy = mouseY / ScaleY | 0;
  x = ox * ScaleX;
  y = oy * ScaleY;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + ScaleX * iw, y);
  ctx.lineTo(x + ScaleX * iw, y + ScaleY * ih);
  ctx.lineTo(x, y + ScaleY * ih);
  ctx.lineTo(x, y);
  ctx.stroke();
}

loop = () => {

  if (!complete) {
    if (SELECTED_BG == 'transparent'){
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    else if (typeof SELECTED_BG == 'object'){
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    else{
      const bgI = new Image();
      bgI.src = `${SELECTED_BG}`;
      ctx.drawImage(bgI, 0, 0, canvas.width, canvas.height);
    }
    ctx.lineWidth = 1;
    ctx.strokeStyle = 'black';
    for (let x of columns) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y of rows) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }
  }
  else{
    if (SELECTED_BG == 'transparent'){
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
    else if (typeof SELECTED_BG == 'object'){
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    else{
      const bgI = new Image();
      bgI.src = `${SELECTED_BG}`;
      ctx.drawImage(bgI, 0, 0, canvas.width, canvas.height);
    }
  }
  Object.keys(positions).forEach((pos, index) => {
    try {
      ctx.drawImage(positions[pos]['img'],
      positions[pos]['x'],
      positions[pos]['y'],
      ScaleX * positions[pos]['w'],
      ScaleY * positions[pos]['h']);
    }
    catch {
      if (positions[pos]) {
        delete positions[pos];
      }
    }
  });
  if (!complete) {
    ctx.lineWidth = 2;
    Object.keys(ImagesData).forEach((key) => {
      if (ImagesData[key]['selected']) {
        iw = ImagesData[key]['width'];
        ih = ImagesData[key]['height'];
        showplace(iw, ih);
      }
    });
    ctx.fillStyle = 'green';
    ctx.fillRect(mouseX, mouseY, 4, 4);
    ctx.fillStyle = rgbRender.style.backgroundColor;
  }
  requestAnimationFrame(loop);
}


loop();
loadCompleted();

column_manage();
row_manage();

function chack_name() {
  sheetName = document.querySelector('#sheetName');
  name = sheetName.value.trim();
  if (name === '') {
    sheetName.style.color = 'red';
    return false;
  }

  sheetName.style.color = 'black';
  return name;
}

function completeS() {
  name = chack_name();
  if (name == 'false') {
    alert('problem ! chack sheet Name');
    return;
  }
  if (!confirm('Are you sure? \n complete')) {
    return;
  }

  complete = true;
  setTimeout(() => {
    let measured = [];
    Object.keys(positions).forEach((key) => {
      let x = positions[key]['x'];
      let y = positions[key]['y'];
      let width = positions[key]['w'];
      let height = positions[key]['h'];
      let behaver = positions[key]['b'];
      measured.push({
        'x': x, 'y': y, 'width': width,
        'height': height, 'behaver': behaver,
        'scaleX': ScaleX, 'scaleY': ScaleY
      });
    });
    url = canvas.toDataURL('image/png');
    structure = url;
    CompletedData[name] = {
      'measured': measured,
      'structure': structure
    };
    setCompleted();
    loadCompleted();
    alert('Completed !');
    complete = false;
  }, 1000);
}